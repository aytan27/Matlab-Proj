%DICHOTIC SAMPLE DISCRIMINATION EXP +follow up exp
%Goal is to see if listeners are able to weight the target tones equally in
%left and right ear. Listeners are asked to respond if target tones are perceived to be 
%lower in pitch (press 1) or higher in pitch (press 2). 
%Requires circumaural headphones for best effect. 
%Series of seven tones are presented dichotically (i.e., different ears are
%presented with different stimuli). Even tones that are more statistically informative than  
%the odd tones are are presented to the target ear (Left or Right) with hard 
%vs easy presentation level (70 dB for easy, 50 dB hard). 

%Currently set to run 3 blocks with guest subj initials 'tst'
%1000 HZ AND 1100 HZ SAMPLE DISTRIBUTIONS
%Append in front of file name: "D2"-base D3-tone1,3,5,7 d'=0, D4-300iti, D5- 
%lowfs=components 2,4,6 - 50Hz sigma (high information (signal) components)
%highfs=components 1,3,5,7 - 100Hz sigma (low information (noise) components)*
%Condition 1 & 2 = signal in left ear (loud (easy) /quiet (hard))
%follow-up 1: 1 3 5 7 are sampled from same distribution d'pri = 0, saved mat
%as D3
%3.13.15 follow-up 2: 300ms duration for JF(10) and JZ(5) but changed to 300ms ITI
%as D4
%from boothB
%3.30.15 REPLACED dichotic1b in BoothA+B

clear all;
close all;
clc;
rand('state',sum(100*clock));
randn('state',sum(100*clock));

%input parameters
nblks= 1; %input('Number of blocks -------> ');
subj= 'tst'; %input('Subject # ------> ','s');
disp('1=RQ')
disp('2=RL')
disp('3=LQ')
disp('4=LL')
disp('5=BQ')
disp('6=BL')
cond=input('Which Condition ---> ');
query =  'n'; %input('Is this follow-up 1 to improve your d''prime? y= yes or n= no?  ', 's');
query1 = 'n'; %input('Is this follow-up 2 to increase intertone interval to 300ms? y = yes or n= no? ','s');
query2 = 'n'; %input('Is this follow-up 3 to increase intertone interval to 500ms? y = yes or n=no?', 's'); 
query3 = 'n'; %input('Is this follow-up 4 to increase intertone interval to 150ms? y= yes or n=no?','s'); 
if cond<1||cond>6
    error('Please select a condition between 1 and 6');
end

if query1 == 'y'
T_cmp =.06; %60x7 420ms 300ms gap
T_gap = 0.3; %300msITI
elseif query2 == 'y'
    T_cmp=0.06;
    T_gap=0.5;
elseif query3 == 'y'
    T_cmp=.06;
    T_gap=0.150;
else
T_cmp=0.06;
T_gap=T_cmp;
end;

SR=44100;
sr=1/SR;      % sec/sample
% N=T*SR;       %TOTAL POINTS
t=[0:sr:T_cmp-sr];  %Component presentation time
gap=zeros(1,round(T_gap/sr)); %Gap presentation time
gap1=zeros(1,round(T_cmp/sr));

ntrials=100;  % instead of 100 
%CALIBRATION
clc
disp(blanks(12));

idflag=0;
while idflag==0;
calresp= 'n' %input('        Would you like calibrate the signal level y or n? ','s');

if (calresp== 'y') | (calresp== 'n')
  idflag=1;

end; %if
end; %while

if calresp=='y'
    clc
    dummy=input('             Press enter when ready','s');
    while calresp=='y';

        TT=80;
        [calresp]=calibration(TT);

    end;  %while

    
    end; %if
    
clear TT


clc
            switch cond
                case{1} %RQ
            mesg='                            Please attend to your right ear';
            pause(1);
                    noisedB=.85;
                    sigdB=.085;
                case{2} %RL
            mesg='                             Please attend to your right ear';
            pause(1);
                    noisedB=.085;
                    sigdB=.85;
                    
                case{3} %LQ
            mesg='                            Please attend to your left ear';
            pause(1);
                    noisedB=.85;
                    sigdB=.085;
                    
                case{4} %LL
            mesg='                            Please attend to your left ear';
            pause(1);
                    noisedB=.085;
                    sigdB=.85;
                case{5} %DQ Diotic
            mesg='                            Please attend to the quiet tones';
            pause(1);
                    noisedB=.85;
                    sigdB=.085;
                case{6} %DL 
            mesg='                             Please attend to the loud tones';
            pause(1);
                    noisedB=.085;
                    sigdB=.85;                    
            end
           
            disp(blanks(12));
            disp(mesg);
            pause(1);
disp(blanks(12)')
dummy=input('             Press enter when ready','s');
            
%RAMP
rdur=round(.003/sr);
steady=ones(1,length(t)-2*rdur);
rampon = (1/rdur):(1/rdur):1;
rampoff = 1:-(1/rdur):(1/rdur);
ramp=[rampon steady rampoff];


%BLOCK LOOP

w=0;
for blk=1:nblks;
    pause(1) % time delay
    stim=zeros(1,ntrials);
    response=zeros(1,ntrials);
    data=zeros(ntrials,9);
    
    
    %TRIAL LOOP
    for trialnum=1:ntrials;
        pause(1.5);
        
        %draw which distribution to sample from
        if query == 'n'; %not a followup to affect performance
        coin=rand;
        if coin<0.5
            distmu=1000;          %mean
            stim(trialnum)=1;
        else
            distmu=1100;
            stim(trialnum)=2;
        end 
        sigfs = distmu + 50.*randn(3,1); %components 2, 4, 6
        noisefs= distmu + 200.*randn(4,1); %components 1, 3, 5, 7
        
        else query == 'y';
            coin=rand;
        if coin<0.5
            distmu=1000;          %mean
            stim(trialnum)=1;
        else
            distmu=1100;
            stim(trialnum)=2;
        end %if nested
            sigfs = distmu + 50.*randn(3,1); %components 2, 4, 6
            distmux = 1050;
            noisefs= distmux + 200.*randn(4,1); %components 1, 3, 5, 7
        end; %if
        
        %Sig components (st deviation=50 Hz - high information)
        
        cmp2=(sigdB*sin(2*pi*sigfs(1)*t)).*ramp;
        cmp4=(sigdB*sin(2*pi*sigfs(2)*t)).*ramp;
        cmp6=(sigdB*sin(2*pi*sigfs(3)*t)).*ramp;

     
        %Noise components (st deviation=200 Hz - low information)
        
        cmp1=(noisedB*sin(2*pi*noisefs(1)*t)).*ramp;
        cmp3=(noisedB*sin(2*pi*noisefs(2)*t)).*ramp;
        cmp5=(noisedB*sin(2*pi*noisefs(3)*t)).*ramp;
        cmp7=(noisedB*sin(2*pi*noisefs(4)*t)).*ramp;
       
            
        
%         %Sig components (st deviation=50 Hz - high information)
%         sigfs = distmu + 50.*randn(3,1); %components 2, 4, 6
%         cmp2=(sigdB*sin(2*pi*sigfs(1)*t)).*ramp;
%         cmp4=(sigdB*sin(2*pi*sigfs(2)*t)).*ramp;
%         cmp6=(sigdB*sin(2*pi*sigfs(3)*t)).*ramp;
% 
%      
%         %Noise components (st deviation=200 Hz - low information)
%         noisefs= distmu + 200.*randn(4,1); %components 1, 3, 5, 7
%         cmp1=(noisedB*sin(2*pi*noisefs(1)*t)).*ramp;
%         cmp3=(noisedB*sin(2*pi*noisefs(2)*t)).*ramp;
%         cmp5=(noisedB*sin(2*pi*noisefs(3)*t)).*ramp;
%         cmp7=(noisedB*sin(2*pi*noisefs(4)*t)).*ramp;
%        
          

        out1=([cmp1 gap gap1 gap cmp3 gap gap1 gap cmp5 gap gap1 gap cmp7 gap]);
        out2=([gap1  gap cmp2 gap gap1 gap cmp4 gap gap1 gap cmp6 gap gap1 gap]); 
%         out3=([cmp1 gap cmp2 gap cmp3 gap cmp4 gap cmp5 gap cmp6 gap cmp7 gap]);
        
       cmpdata=[noisefs(1) sigfs(1) noisefs(2) sigfs(2) noisefs(3) sigfs(3) noisefs(4)];
 
        if cond==1 || cond==2 % 2,4,6 to right ear 
            out=[out1' out2'];
        elseif cond==3 || cond==4 % 2,4,6 to left  
                out=[out2' out1'];
                
        else
            out=[out3' out3'];%right
        end

        
        player= audioplayer(out,SR,24);
        play(player);
        isp = isplaying(player); %0 = playback not in progress, 1 playback in progress

        while isp  %logical is 0 automatically breaks out of the program
            ListenChar(2); %freeze keyboard while playback is in session 
            isp = isplaying(player); %continuously check if playblack is 1, if 0, breaks out
        end
        ListenChar(0);
            
        
        %RESPONSE
        clc
        dum=0;
        disp([blanks(45) '# of trials' blanks(2) int2str(trialnum) blanks(2) 'out of' blanks(2) int2str(ntrials) blanks(2) 'trials'])

        while dum==0      %loop until subject resp 1 or 2
            
            
            disp(blanks(12)');
            message=[blanks(30) 'Respond 1 or 2 ---> '];
            resp=input(message,'s');
            if (resp=='1') | (resp=='2')
                dum=1;
                
            end
            
        end
        
       
            
        response(trialnum)=str2num(resp);%Converts string variable back to integer

        %FEEDBACK
        correct=1;
        disp(' ')
        message1=[blanks(35) 'Correct'];
        message2=[blanks(35) 'Incorrect'];
        if response(trialnum)==stim(trialnum)
            disp(message1)
        else
            disp(message2)
            
            correct=0;
        end
        
        

        data(trialnum,:)=[stim(trialnum) response(trialnum) cmpdata];
    end   %trialloop

    %CALCULATE BLOCK d'
    hittrials=find(response==1&stim==1);
    h=length(hittrials);
    slength=find(stim==1);
    strials=length(slength);
    hitp=h/strials;
    fatrials=find(response==1&stim==2);
    fa=length(fatrials);
    nslength=find(stim==2);
    nstrials=length(nslength);
    fap=fa/nstrials;
    
    dprime = icdf('Normal',hitp,0,1) - icdf('Normal',fap,0,1); %Z(HR)-Z(FA)

    pause(0.5);
    %DISPLAY d'
     clc
    disp(blanks(10)');
    disp([blanks(25) 'd-prime = ' num2str(dprime)]);
    pause(1)
    bcomplete = sprintf('Block %d Completed', blk);
    disp([blanks(25) bcomplete])

    datetrack=getdate;
    %FILE NAME CREATION
    if query == 'y'
        id='D3';
    elseif query1 == 'y'
    id='D4';
    elseif query2 == 'y'
        id='D5';
    elseif query3 == 'y'
        id = 'D6';
    else
        id='D2';
    end; %if query
    underscore='_';
    blkfilename=[id subj underscore num2str(cond) underscore num2str(blk) datetrack];

    %SAVE DATAFILE
    dprimes(cond,blk)=dprime;

    save(blkfilename,'data','response', 'stim', 'sigfs', 'noisefs', 'cond', 'subj', 'blk', 'noisedB', 'sigdB', 'T_cmp','T_gap','dprime');
    save dprimes dprimes
    w=w+1;
    if w~=nblks
        disp(blanks(6)')
        disp([blanks(25) 'Hit any key to begin the next block'])
        pause;
        clc
        close
    else disp(blanks(6)')
        disp([blanks(25) 'You have completed all blocks.  Thank you!']);
        close
    end

end       %blkloop

