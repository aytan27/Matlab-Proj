function [filedate]=getdate

time=clock;
switch time(2);
case 1
   month='JAN';
case 2
   month='FEB';
case 3
   month='MAR';
case 4
   month='APR';
case 5
   month='MAY';
case 6
   month='JUN';
case 7
   month='JUL';
case 8
   month='AUG';
case 9
   month='SEP';
case 10
   month='OCT';
case 11
   month='NOV';
case 12
   month='DEC';
end
d=num2str(time(3));
h=time(4);
if h>12 h=h-12;
end;
h=num2str(h);
min=num2str(time(5));

filedate=[month d '-' h '-' min];
end

