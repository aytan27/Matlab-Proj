%Aytan

% Sample data for subj JF is provided as an example to run this code. This analyzes dichotic sample discrimination .dir files by date and finds the point where the minimum rms
% is achieved.  Data files with min RMS(root-mean-square value) are then analyzed for weights and
% plotted. The weights expected for a listener who is able to listen to the target tones are shown by a peak at tones 2, 4, 6 as shown on the x-axis.  
% getdate fxn used
%
% automatically saves figs as jpgs
%Jan 16 2015 axis to wgts figure is adjusted, less whitespace
%Jan 19 2015- independent function call to calculate measures of efficiency included
%1.26.15-query whetherean subj wants to save figs during analysis
%2.3.15- if sub does not save images, imgsave 'n', output will not write into outfile as well
%2.10.15 zero out negative weights
%3.10.15-save efficiency measures in datamat folder
%3.11.15 will analyze duration followup
%4.3.15 will read in all data types(issue with efficiency), zero out negative wgts at the end.
%onBOOTHB
clear all
close all


defPath = pwd;
addpath(genpath([defPath]),'-end');
querys='n'; %input('Are you analyzing data on a d''prime followup D3? ---> y or n ?', 's');
querys1='n';%input('Are you analyzing data on 300ms followup  D4? ---> y or n ?', 's');
querys2='n';%input('Are you analyzing data on 500ms followup D5? ---> y or n ?', 's');
querys3='n';%input('Are you analyzing data on 150ms followup D6? ---> y or n ?', 's');
subj= 'JF'; %input('subject initials ---> ','s');
cond=input('which condition (1-4)------>? ');
imgsave=input('Would you like to save the images on this analysis? ''y or n '' ?------> ','s');
rundate= getdate; %datestr(currentdate,'mmmdd');
tf = ismac;

if tf == 1;
    if querys2 == 'y'
        files = dir([defPath '/' sprintf('D5%s_%d*.mat', subj,cond)]);
    elseif querys3 == 'y'
        files = dir([defPath '/' sprintf('D6%s_%d*.mat', subj,cond)]);
    elseif querys == 'y'
    files = dir([defPath '/' sprintf('D3%s_%d*.mat',subj,cond)]);
    elseif querys1== 'y'
    files =	dir([defPath '/' sprintf('D4%s_%d*.mat',subj,cond)]);
    else
    files =	dir([defPath '/' sprintf('D2%s_%d*.mat',subj,cond)]);
    end;
else
    if querys2 == 'y'
        files = dir([defPath '\' sprintf('D5%s_%d*.mat', subj,cond)]);
    elseif querys3 == 'y'
        files= dir([defPath '\' sprintf('D6%s_%d*.mat', subj,cond)]);
    elseif querys == 'y'
    files = dir([defPath '\' sprintf('D3%s_%d*.mat',subj,cond)]);
    elseif querys1=='y'
        files =	dir([defPath '\' sprintf('D4%s_%d*.mat',subj,cond)]);
    else
        files =	dir([defPath '\' sprintf('D2%s_%d*.mat',subj,cond)]);
    end;%nested
end;

if size(files,1) > 0
    nfiles=size(files,1);
    totfiles=nfiles;
    elseif size(files,1) ==0

    disp(blanks(5)');
    disp([blanks(25) 'ERROR: There are no data files for this subject/condition in the directory '])
    break
end

S = [files(:).datenum].';  % you may want to eliminate . and .. first.
[S,idx] = sort(S, 'descend'); % last block first
B = {files(idx).name};  % Cell array of names in order by datenum

xfiles=nfiles;
allrms=zeros(1,nfiles-4);
xnotation=allrms;
dprimes=[];

for totfiles=nfiles:-1:4;

    %get data
    alldata=[];
 
    
    for filenum=1:totfiles;
        load(B{filenum});
        %  disp(tline)
%         load(tline);
        alldata=[alldata
            data];

%         if totfiles==nfiles
%             dprimes=[dprimes dprime];
%         end
    end
    
    data=alldata;
    [trls,datsize]=size(data);
    ncomp=datsize-2; %ncomp1 for corrcef matrix
    
    %Low Interval
    index=find(1==data(:,1));
    data=data(index,:);
    data(:,3:datsize)=(data(:,3:datsize));
    data(:,1)=[];    %clear signal column
    tmp=corrcoef(data);
    r=tmp(1,2:ncomp+1);
    wgt1=r./max(abs(r));
    wgt1=wgt1./sum(wgt1);
%     wgtindex1 = find(wgt1 < 0);
%     wgt1(wgtindex1) = 0;

    %High Interval
    data=alldata;
    index=find(2==data(:,1));
    data=data(index,:);
    data(:,3:datsize)=(data(:,3:datsize));
    data(:,1)=[];    %clear signal column
    tmp=corrcoef(data);
    r=tmp(1,2:ncomp+1);
    wgt2=r./max(abs(r));
    wgt2=wgt2./sum(wgt2);
%     wgtindex2 = find(wgt2 < 0);
%     wgt2(wgtindex2) = 0;
    %wgt=(wgt1+wgt2)/2;
    %wgt=wgt/max(abs(wgt));
    allrms(nfiles+1-totfiles)=sqrt((wgt1-wgt2)*(wgt1-wgt2)'/ncomp);
    xnotation(nfiles+1-totfiles)=totfiles;
end %totfiles (jjj)
h = figure;
set(gcf,'PaperPositionMode','auto')
plot(xnotation,allrms)
title('Number of blocks used in rms calulation');
xlabel('Block Number');
ylabel('rms');

if imgsave == 'y';
filen=['D2' subj 'C' num2str(cond) ' ' num2str(nfiles) ' '  'rms' ' ' num2str(rundate)];  
if querys == 'y';
    filen=['D3' subj 'C' num2str(cond) ' ' num2str(nfiles) ' '  'rms' ' ' num2str(rundate)]; 
elseif querys1 == 'y';
filen=['D4' subj 'C' num2str(cond) ' ' num2str(nfiles) ' '  'rms' ' ' num2str(rundate)];
elseif querys3 == 'y';
    filen=['D6' subj 'C' num2str(cond) ' ' num2str(nfiles) ' '  'rms' ' ' num2str(rundate)];
end;
    filena=[filen '.jpg'];
print(gcf,'-djpeg',filena);
else imgsave == 'n';
end;


%$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
%recalculate weights for minimum rms
allrms=fliplr(allrms);
% index=min(allrms);
% nfiles=find(index==allrms)+3;

[value_rms,ind] =min(allrms);
if value_rms < 0.05;
    index_value = find(allrms <= 0.05);
    indexy = allrms(index_value);
    nfiles = index_value+3;
    nfiles = max(nfiles);
elseif value_rms > 0.05;
nfiles=ind+3;
end;



%get data
alldata=[];
% fid=fopen(filename,'rt');
for filenum=1:nfiles;
%     tline = fgetl(fid);
    %  disp(tline)
%     load(tline);
    load(B{filenum})
    alldata=[alldata
        data];
    
    dprimes=[dprimes dprime]; %only open and calculate dprimes necessary t
end
% fclose(fid);
data=alldata;
[trls,datsize]=size(data);
ncomp=datsize-2;

%Low Interval
index=find(1==data(:,1));
data=data(index,:);
data(:,3:datsize)=(data(:,3:datsize));
data(:,1)=[];    %clear signal column
tmp=corrcoef(data);
r=tmp(1,2:ncomp+1);
wgt1=r./max(abs(r));
wgt1=wgt1./sum(wgt1);
wgtindex1 = find(wgt1 < 0);
wgt1(wgtindex1)= 0;

%High Interval
data=alldata;
index=find(2==data(:,1));
data=data(index,:);
data(:,3:datsize)= data(:,3:datsize);
data(:,1)=[];    %clear signal column
tmp=corrcoef(data);
r=tmp(1,2:ncomp+1);
wgt2=r./max(abs(r));
wgt2=wgt2./sum(wgt2);
wgtindex2 = find(wgt2 < 0); %rms is higher if you don't zero out weights at end
wgt2(wgtindex2) = 0;

wgt=(wgt1+wgt2)/2;
wgt=wgt./sum(wgt);
rms=sqrt((wgt1-wgt2)*(wgt1-wgt2)'/ncomp);
nfiles;
minrmsfiles=nfiles;
%PLOT WEIGHTS
h1 = figure;
set(gcf,'PaperPositionMode','auto')
lowf=[2 4 6];
highf=[1 3 5 7];
axis([1,7,0,0.6]);
hold on

plot(wgt1);
plot(wgt2,'r');
plot(wgt,'gp');
title('WEIGHTS');
if imgsave == 'y'
filen=['D2' subj 'C' num2str(cond) ' ' num2str(xfiles) ' '  'wgt' ' ' num2str(rundate)]; 
if querys == 'y';
    filen=['D3' subj 'C' num2str(cond) ' ' num2str(xfiles) ' '  'wgt' ' ' num2str(rundate)];
elseif querys1 == 'y';
    filen=['D4' subj 'C' num2str(cond) ' ' num2str(nfiles) ' '  'wgt' ' ' num2str(rundate)];
elseif querys3 == 'y';
    filen=['D6' subj 'C' num2str(cond) ' ' num2str(nfiles) ' '  'wgt' ' ' num2str(rundate)];
else
end;
filena=[filen '.jpg'];
print(h1,'-djpeg',filena);
else
end;
hold off

avgdprimes=mean(dprimes);
h2=figure;
set(gcf,'PaperPositionMode','auto')
plot(dprimes)
set(gca,'YTick', [0:.5:3.5]);
ylim([0 3.5])
title('d''prime');
xlabel('Block');
ylabel('d''prime');

if imgsave == 'y';
filen=['D2' subj 'C' num2str(cond) ' ' num2str(xfiles) ' '  'dpri' ' ' num2str(rundate)];  
    if querys == 'y';
    filen=['D3' subj 'C' num2str(cond) ' ' num2str(xfiles) ' '  'dpri' ' ' num2str(rundate)];
    elseif querys1 == 'y';
    filen=['D4' subj 'C' num2str(cond) ' ' num2str(nfiles) ' '  'dpri' ' ' num2str(rundate)];
    elseif querys3 == 'y';
        filen=['D6' subj 'C' num2str(cond) ' ' num2str(nfiles) ' '  'dpri' ' ' num2str(rundate)];
    end
filena=[filen '.jpg'];
print(h2,'-djpeg',filena);
else 
end;



%CALCULATE INTERNAL NOISE
aiarray=zeros(100,ncomp);
ai=wgt./sum(wgt);


xtrial=1;
for nn=1:xfiles
    %get data
    alldata=[];

%     fid=fopen(filename,'rt');
    for filenum=1:xfiles;
%         tline = fgetl(fid);
        %  disp(tline)
%         load(tline);
       load(B{filenum})
        alldata=[alldata
            data];


    end
%     fclose(fid);
    datsize = size(alldata,2);
    xi=alldata(:,3:datsize); %frequency/perturbations
    xtrials=length(xi);
    sumaixi=zeros(1,xtrials);
    aiarray=repmat(ai,xtrials,1); %generate tiles of weights
    for tt=1:xtrials
    sumaixi(tt)=sum(aiarray(tt,:).*xi(tt,:)); %multiple matrix of wgts with alldata 3:7
    end
xtrial=xtrial+1;
end
response=alldata(:,2);
minfreq=min(sumaixi);
maxfreq=max(sumaixi);
freqrange=round(maxfreq-minfreq);
sumaixi=sumaixi';
respindex=[response sumaixi];
yy=find(respindex(:,1)==2);
xx=sortrows(respindex(yy,:),2); %high
intnoisehigh=mle(xx(:,2));
ww=find(respindex(:,1)==1); %distr low
zz=sortrows(respindex(ww,:),2);
intnoiselow=mle(zz(:,2));
intnoise=mle(respindex(:,2));
freqbins=minfreq:5:maxfreq;

[ dwgt,aidawgt,aidanoise,aidaobs,dpred ] = efficiency(wgt,avgdprimes,intnoise,ncomp) %calculate measures of efficiency per condition

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%STOP
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%POINT!!!!!!!!!!!!!

%Save data output
clc;
% currentdate=date;

disp(blanks(30));
disp(['Date = ' rundate])
disp(blanks(30));
disp(['rms = ' num2str(rms)])
disp(blanks(30));
disp(['Total number of files = ' num2str(xfiles)])
disp(blanks(30));
disp(['Minimum rms files = ' num2str(minrmsfiles)])
disp(blanks(30));
disp(['dprime average = ' num2str(avgdprimes)])
disp(blanks(30));
disp(['Internal noise resp("high") (mu,sigma) =' num2str(intnoisehigh)])
disp(blanks(30));
disp(['Internal noise resp("low") (mu,sigma) =' num2str(intnoiselow)])
disp(blanks(30));
disp(['Internal noise =' num2str(intnoise)])
disp(blanks(30));
disp(['Dwgt =' num2str(dwgt)])
disp(blanks(30));
disp(['Aidawgt =' num2str(aidawgt)])
disp(blanks(30));
disp(['Aidanoise =' num2str(aidanoise)])
disp(blanks(30));
disp(['Aidaobs =' num2str(aidaobs)])
disp(blanks(30));
disp(['d''predicted =' num2str(dpred)])

if querys2 == 'y'
    condition = ['D5' num2str(cond)];
elseif querys == 'y'
    condition = ['D3' num2str(cond)];
elseif querys1 == 'y'
    condition = ['D4' num2str(cond)];
elseif querys3 == 'y'
    condition = ['D6' num2str(cond)];
else
condition=['D2' num2str(cond)];
end; 
outfile=[condition rundate '_' subj];

% if tf == 1;
% save([defPath '/Datamat/' outfile],'subj','xfiles','rms','minrmsfiles','avgdprimes','dprimes','intnoise','intnoisehigh','intnoiselow','wgt1','wgt2','wgt','sumaixi','dpred','aidawgt','dwgt','aidanoise','aidaobs');
% else
% save([defPath '\Datamat\' outfile],'subj','xfiles','rms','minrmsfiles','avgdprimes','dprimes','intnoise','intnoisehigh','intnoiselow','wgt1','wgt2','wgt','sumaixi','dpred','aidawgt','dwgt','aidanoise','aidaobs');
% end;
    
fid=fopen('outfile.txt','a+');
fprintf(fid, 'subj= %s\n', subj);
fprintf(fid, 'cond= %d\n', cond);
fprintf(fid, 'date= %s\n', rundate);
fprintf(fid, 'xfiles=  %d\n',xfiles); 
fprintf(fid, 'rms=  %d\n', rms);
fprintf(fid, 'minrmsfiles= %d\n', minrmsfiles);
fprintf(fid, 'avgdprimes= %d\n', avgdprimes);
fprintf(fid, 'dprimes=  %d\n', dprimes);
fprintf(fid, 'intnoise= %d\n', intnoise);
fprintf(fid, 'internal noise resp high (mu,sigma) = %d\n', intnoisehigh);
fprintf(fid, 'internal noise resp low  (mu,sigma) = %d\n', intnoiselow);
fprintf(fid, 'wgt1=  %d\n', wgt1);
fprintf(fid, 'wgt2= %d\n', wgt2);
fprintf(fid, 'wgt= %d\n', wgt);
fprintf(fid, 'dwgt= %d\n', dwgt);
fprintf(fid, 'aidawgt= %d\n', aidawgt);
fprintf(fid, 'aidanoise= %d\n', aidanoise);
fprintf(fid, 'aidaobs= %d\n', aidaobs);
fprintf(fid, 'd''predicted = %d\n', dpred);

% fprintf(fid, 'sumaixi= %d\n', sumaixi);
fclose(fid);


