function [ dwgt, aidawgt, aidanoise, aidaobs,dpred ] = efficiency(wgt, avgdprimes,intnoise,ncomp)
% function [ dwgt,aidawgt,aidanoise,aidaobs ] = efficiency(wgt,avgdprimes)
    %function inefficency
    %aytan
    %Calculate efficiencies for each condition of sample discrimination
    %task
    % dpred added 2.25.15

dideal = sqrt(13);
% dideal = 13;
deltamu = 100;
dobs = avgdprimes;
sigmax = [200 50 200 50 200 50 200];
sigma= sigmax(1: ncomp);
ai = wgt;
a = wgt.^2; 
b = sigma'.^2;

dpred = 100/sqrt(sum(a*b)+intnoise(1,2)^2);
% dpred = 100/sqrt(sum(a*b)+intnoise(1,2));

dwgt = deltamu*sum(ai)/sqrt(sum(a*b));
% dwgt = deltamu*sum(ai)/sqrt((sum(a.*b)));
aidawgt = (dwgt/dideal)^2;
aidanoise = (dpred/dwgt)^2;
aidaobs = (dpred/dideal)^2;

% dpred = 100/sqrt((sum(a*b))+intnoise(1,2)^2); %dprime predicted

% idealai=[.0192 .3077 .0192 .3077 .0192 .3077 .0192];

%%%%aidawgt calculation check, for AT cond 3 same as using sqrt(13) as
%%%dideal
%sum((ai.^2*sigma'.^2))  %d'ideal sqrt
%sum((idealai.^2*sigma'.^2))%dwgt
%%%ideal weights
% aix= 1./((sigma.^2)*sum(1./sigma.^2)) %calculate ideal weight
%ideal for 3tone 0.0556    0.8889    0.0556