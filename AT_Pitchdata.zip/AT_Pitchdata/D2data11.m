 %D2data11 open on MAC
% Can insert a wildcard after subj name e.g AR*.mat depending on condition
% where all files under said category will be analyzed
% Useful when you want to see learning curve plot and thresholds
% Format: subj_C_cond_category_blocknum_date&time   
%Cond: 1-10hzrx(R alone) 2-10hz (R/L) 3-40hz (R/L/P)
%Category: R L P (or T-test)
% added level perturbations so they can be computed with three other
% weights
%LEVEL ROVE saved in data matrix, treat like weights: 
%[stim resp pertstandard rovescalarstand pertsig rovescalarsig]
%thresholds plot now shows the last block in the first bin
%March 4 2014 (min to max block) one off
%July 7 2014 have option to compile data that allows you to ignore level
%rove columns in data matrix

clear all
close all

defPath = pwd;
addpath(genpath([defPath]),'-end');
subj=input('subject initials --->','s');
cond=input('which condition (ie: 1,2,3,4,5..)------>?');
category=input ('what did you listen to? R L P ---> ', 's');

% totfiles=input('How many files ?');
rovignore=2; %input('Do you want to analyze a mix of files(ones with level perturbation and ones without? 1=yes 2=no ' ); 
    

files        =	dir([defPath '/' sprintf('%sC%d%s*.mat',subj,cond,category)]);
if size(files,1) > 0
    nfiles=size(files,1);
    totfiles=nfiles;
    elseif size(Filename,1) ==0

    disp(blanks(5)');
    disp([blanks(25) 'ERROR: There are no data files for this subject/condition in the directory '])
    break
end

S = [files(:).datenum].';  % you may want to eliminate . and .. first.
[S,idx] = sort(S, 'descend'); % last block first
B = {files(idx).name};  % Cell array of names in order by datenum

%OBTAIN THRESHOLDS AND REVERSALS TO CALCULATE AVERAGE THRESHOLD
 
      allavgthresh=[];
    for filenum = 1:totfiles;       %Keep in mind the 10-1 order when plotting      
        load(B{filenum})
        
        allavgthresh=[allavgthresh
                       avgthresh];

    end;%for
    
    
    
 % Average Threshold
%    thresh = allthresh;
%    rev= allrev
%     B=  repmat(allrev,
% avgthresh(nfiles+1-totfiles) =(diag(thresh(:,3:70+2)*allrev'))./(sum(allrev,2))  % +2 part used to be kk+2 but here it's fixed at 70trials
 
  totalavgthresh= mean(allavgthresh,1); %to find the average threshold across all blocks
 %allavgthresh=flipud(allavgthresh); %from block 1 to last block   


 figure 
 subplot (2,1,1), plot(allavgthresh) %% shows from last block's threshold and so forth
 title('Average Threshold by block');
 xlabel ('Block Number');
 ylabel('Threshold');
 

 
xfiles=nfiles;
allrms=zeros(1,nfiles-2);
xnotation=allrms;
% dprimes=[];


if rovignore==1 %to analyze mixed files
    
     for totfiles = nfiles:-1:2;  
          alldata=[];  
   
         if (size(data(1,:),2) > 8)  %in order to CAT due to differ dimensions     
             data(:,6)=[]; % 1 2 3 4 5 6 7 8 9 (when col 6 is gone)
             data(:,9)=[];  
         end %if
          
         for filenum = 1:totfiles;           
            load(B{filenum})

            if (size(data(1,:),2) > 8)  %loading up a new mat file everytime      
                 data(:,6)=[]; % 1 2 3 4 5 6 7 8 9 (when col 6 is gone)
                 data(:,9)=[];  
            end %if 

            alldata=[alldata 
                      data]; 
          end%for
       
    
    data= alldata;
    
    prtbstandard=data(:,3:5);                   %column 3 through column 5 as perturbations of the standard
    prtbsig=data(:,6:8);
    
Int1= (prtbstandard - prtbsig);             %% *-1 prtb difference from pertsig to pertstd 
Int2= (Int1) * -1;
datainterval1 = [data(:,1:2) Int1];            %Creating matrix with column 1 to Column 2 and the prtb difference
datainterval2 = [data(:,1:2) Int2];             %values for when signal was in the first interval
                                                %and another datainterval2
                                                %matrix to account for when
                                                %signal is in 2nd interval

x= datainterval1(:,1)==1;               %check data in vector for all rows in Column 1-STIM, where the value ==1 (sig standard)
data1=datainterval1(x,:);                     %data1 contains when stim ==1, for all columns associated 
y=find(datainterval2(:,1)==2);               %all the rows in column 1 when value ==2
data2=datainterval2(y,:); 



 
%deleting column 1 from data
data1(:,1)=[];                      %all rows for column one which was STIM deleted               
data2(:,1)=[];                      %all rows for column one from data2 deleted



                                         %R P1 P2 P3 (R=responses) 
                                     %R   1
                                     %P1     1
                                     %P2        1
                                     %P3          1
    
r1=corrcoef(data1) ;                 %get the correlated coefficients for vector data 1                               
w1=r1(1,2:4);                        %matrix row 1 from 2column to the 5column (instead of 4, leve rove) holds the corcoeff needed
maxw1=max(abs(w1));                  %highest abs value from the corrcoeff matrix
w1=w1/maxw1 ;                          %normalize over the maximum value
% w1= -1*w1

r2=corrcoef(data2);                 %correlation coefficient for set of data when stim was 2 
w2=r2(1,2:4);                       %weights are values found in row 1 from column 2-5 due to level rove weights
maxw2=max(abs(w2));                  %normalizing by the largest value weight
w2= w2/maxw2;                         
% w2= -1*w2 ;         %sign change not above (*-1)
% wgts=(w1+w2)/2;                     %take the average 

    

    ncomptone=3;                  %# of tone complexes or in the future use length(w1)
    allrms(nfiles+1-totfiles)=sqrt((w1-w2)*(w1-w2)'/ncomptone); %
    xnotation(nfiles+1-totfiles)=totfiles;
    
end;
    
subplot(2,1,2), plot(xnotation,allrms)
title('Blocks used in rms calculation');
xlabel('Each block number is subtracted from the very last block completed');
ylabel('rms');
pause


%$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
%recalculate weights for minimum rms
allrms=fliplr(allrms); %flip because this affects index location
[C,I]=min(allrms); % returns C as scalar value for rms and 'I' as the index for where it is located on vector
nfiles=I+1;   %find(index==allrms) I+2 if totfiles goes down to 3           


allrms=fliplr(allrms); %flip because this affects index location
[C,I]=min(allrms); % returns C as scalar value for rms and 'I' as the index for where it is located on vector
nfiles=I+1;   %find(index==allrms)            


%get data
alldata=[];
if (size(data(1,:), 2) > 8)
       data(:,6)=[];
       data(:,9)=[];
   end; %if
 
for filenum=1:nfiles; 
   load(B{filenum})
   
   if (size(data(1,:), 2) > 8)
       data(:,6)=[];
       data(:,9)=[];
   end; %if
   
    alldata=[alldata
        data];
    
end; %for

data=alldata;
    
    
prtbstandard=data(:,3:5);                   %all the rows for column 3 through column 5 for pertstd
prtbsig=data(:,6:8);                        %all the rows for column 6 through column 8 pertsig
Int1= (prtbstandard - prtbsig);             %% Int 1 when signal is in interval 1,  difference from pertsig to pertstd 
Int2= (Int1)* -1;

datainterval1 = [data(:,1:2) Int1];            %creating matrix with all the rows for column 1 to Column 2 and 4
datainterval2 = [data(:,1:2) Int2];            %3 prtb difference values for when signal was in the first interval
                                                %and another datainterval2
                                                %%matrix to account for
                                                %%when signal is in 2nd interval
                                                

x=find(datainterval1(:,1)==1);               %check datainterval1 matrix for Column 1-STIM, where the value ==1 (sig standard)
data1=datainterval1(x,:);                     %data1 contains when stim ==1, for all columns associated 
y=find(datainterval2(:,1)==2);               %looking in matrix datainterval2 for column 1 when value ==2
data2=datainterval2(y,:); 


%deleting column 1 from data
data1(:,1)=[];                      %all rows for column one deleted               
data2(:,1)=[];                      %all rows for column one from data2 deleted



                                         %R P1 P2 P3 
                                     %R   1
                                     %P1     1
                                     %P2        1
                                     %P3          1
                                     
r1=corrcoef(data1);                  %get the correlated coefficients for vector data 1                               
w1=r1(1,2:4);                       %matrix row 1 from 2column to the 4column holds the corcoeff needed
maxw1=max(abs(w1));                  %highest abs value from the corrcoeff matrix
w1=w1/maxw1;                          %normalize over the maximum value
% w1=-1*w1 ;                            %accounting for the different intervals
    
r2=corrcoef(data2);                 %correlation coefficient for set of data when stim was 2 
w2=r2(1,2:4);                       %weights are values found in row 1 from column 2-4.
maxw2=max(abs(w2));                  %normalizing by the largest value weight
w2= w2/maxw2;                         
% w2= -1*w2   ;                        %sign change here for when not above

wgts=(w1+w2)/2;  
%rms=sqrt((w1-w2)*(w1-w2)'/ncomptone);   %RMS value affected by rovescalar
                                            %columns so original rms value is held from indexing done above, prints out C 
nfiles;
minrmsfiles=nfiles;
startminrmsfiles= xfiles-(nfiles-1); %account for indexing shift
%PLOT WEIGHTS
figure 
axis([0,4,-1,1]);
hold on

plot(w1);
plot(w2,'r');
plot(wgts,'gp');
title('WEIGHTS');
legend('wgt1','wgt2','average')
pause
% hold off

clc;
currentdate=date;
rundate=datestr(currentdate,'mmmdd');
disp(blanks(30));
disp(['Date = ' rundate])
disp(blanks(30));
disp(['rms = ' num2str(C)])
disp(blanks(30));
disp(['Total number of files = ' num2str(xfiles)])
disp(blanks(30));
disp(['Files opened starting from file: ' num2str(startminrmsfiles) blanks(2) 'to' blanks(2) num2str(xfiles)])
disp(blanks(30));
disp(['Minimum rms files = ' num2str(minrmsfiles)])
disp(['Minimum rms files = ' num2str(minrmsfiles)])
disp(['Average threshold = ' num2str(totalavgthresh)])              
    
elseif rovignore == 2 %rovignore ==2

if (size(data,2) > 8) 
for totfiles = nfiles:-1:2;               %only goes down to the 1st file  

    %get data
    
    alldata=[];
   
    
      for filenum = 1:totfiles;             
       
        load(B{filenum})
        
        alldata=[alldata 
                  data]; 
              
%         if totfiles==nfiles
%             dprimes=[dprimes dprime];
%         end
    end; %for
    
    data= alldata;
   
 prtbstandard=data(:,3:6);                   %column 3 through column 5 as perturbations of the standard
 prtbsig=data(:,7:10); 


 Int1= (prtbstandard- prtbsig);             %% *-1 prtb difference from pertsig to pertstd 
 Int2= (Int1) * -1;
datainterval1 = [data(:,1:2) Int1];            %Creating matrix with column 1 to Column 2 and the prtb difference
datainterval2 = [data(:,1:2) Int2];             %values for when signal was in the first interval
                                                %and another datainterval2
                                                %matrix to account for when
                                                %signal is in 2nd interval

x= datainterval1(:,1)==1;               %check data in vector for all rows in Column 1-STIM, where the value ==1 (sig standard)
data1=datainterval1(x,:);                     %data1 contains when stim ==1, for all columns associated 
y=find(datainterval2(:,1)==2);               %all the rows in column 1 when value ==2
data2=datainterval2(y,:); 



 
%deleting column 1 from data
data1(:,1)=[];                      %all rows for column one which was STIM deleted               
data2(:,1)=[];                      %all rows for column one from data2 deleted



                                         %R P1 P2 P3 (R=responses) 
                                     %R   1
                                     %P1     1
                                     %P2        1
                                     %P3          1
    
r1=corrcoef(data1) ;                 %get the correlated coefficients for vector data 1                               
w1=r1(1,2:5);                        %matrix row 1 from 2column to the 5column (instead of 4, leve rove) holds the corcoeff needed
maxw1=max(abs(w1));                  %highest abs value from the corrcoeff matrix
w1=w1/maxw1 ;                          %normalize over the maximum value
% w1= -1*w1

r2=corrcoef(data2);                 %correlation coefficient for set of data when stim was 2 
w2=r2(1,2:5);                       %weights are values found in row 1 from column 2-5 due to level rove weights
maxw2=max(abs(w2));                  %normalizing by the largest value weight
w2= w2/maxw2;                         
% w2= -1*w2 ;         %sign change not above (*-1)
% wgts=(w1+w2)/2;                     %take the average 

    

    ncomptone=3;                  %# of tone complexes or in the future use length(w1)
    allrms(nfiles+1-totfiles)=sqrt((w1-w2)*(w1-w2)'/ncomptone); %
    xnotation(nfiles+1-totfiles)=totfiles;
    
end; %totfiles (jjj)
% xnotation=fliplr(xnotation);
% subplot(2,1,2), 

subplot(2,1,2), plot(xnotation,allrms)
title('Blocks used in rms calculation');
xlabel('Each block number is subtracted from the very last block completed');
ylabel('rms');
pause


%$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
%recalculate weights for minimum rms
allrms=fliplr(allrms); %flip because this affects index location
[C,I]=min(allrms); % returns C as scalar value for rms and 'I' as the index for where it is located on vector
nfiles=I+1;   %find(index==allrms)            


%get data
alldata=[];

for filenum=1:nfiles;
    load(B{filenum})
    alldata=[alldata
        data];
end; %for


data=alldata;
prtbstandard=data(:,3:6);                   %all the rows for column 3 through column 5 for pertstd
prtbsig=data(:,7:10);                        %all the rows for column 6 through column 8 pertsig
Int1= (prtbstandard - prtbsig);             %% Int 1 when signal is in interval 1,  difference from pertsig to pertstd 
Int2= (Int1)* -1;

datainterval1 = [data(:,1:2) Int1];            %creating matrix with all the rows for column 1 to Column 2 and 4
datainterval2 = [data(:,1:2) Int2];            %3 prtb difference values for when signal was in the first interval
                                                %and another datainterval2
                                                %%matrix to account for
                                                %%when signal is in 2nd interval
                                                

x=find(datainterval1(:,1)==1);               %check datainterval1 matrix for Column 1-STIM, where the value ==1 (sig standard)
data1=datainterval1(x,:);                     %data1 contains when stim ==1, for all columns associated 
y=find(datainterval2(:,1)==2);               %looking in matrix datainterval2 for column 1 when value ==2
data2=datainterval2(y,:); 


%deleting column 1 from data
data1(:,1)=[];                      %all rows for column one deleted               
data2(:,1)=[];                      %all rows for column one from data2 deleted



                                         %R P1 P2 P3 
                                     %R   1
                                     %P1     1
                                     %P2        1
                                     %P3          1
                                     
r1=corrcoef(data1);                  %get the correlated coefficients for vector data 1                               
w1=r1(1,2:5);                       %matrix row 1 from 2column to the 4column holds the corcoeff needed
maxw1=max(abs(w1));                  %highest abs value from the corrcoeff matrix
w1=w1/maxw1;                          %normalize over the maximum value
% w1=-1*w1 ;                            %accounting for the different intervals
    
r2=corrcoef(data2);                 %correlation coefficient for set of data when stim was 2 
w2=r2(1,2:5);                       %weights are values found in row 1 from column 2-4.
maxw2=max(abs(w2));                  %normalizing by the largest value weight
w2= w2/maxw2;                         
% w2= -1*w2   ;                        %sign change here for when not above

wgts=(w1+w2)/2;  
%rms=sqrt((w1-w2)*(w1-w2)'/ncomptone);   %RMS value affected by rovescalar
                                            %columns so original rms value is held from indexing done above, prints out C 
nfiles;
minrmsfiles=nfiles;
startminrmsfiles= xfiles-(nfiles-1); %account for indexing shift
%PLOT WEIGHTS
figure 
axis([0,4,-1,1]);
hold on

plot(w1);
plot(w2,'r');
plot(wgts,'gp');
title('WEIGHTS');
legend('wgt1','wgt2','average')
pause
% hold off

clc;
currentdate=date;
rundate=datestr(currentdate,'mmmdd');
disp(blanks(30));
disp(['Date = ' rundate])
disp(blanks(30));
disp(['rms = ' num2str(C)])
disp(blanks(30));
disp(['Total number of files = ' num2str(xfiles)])
disp(blanks(30));
disp(['Files opened starting from file: ' num2str(startminrmsfiles) blanks(2) 'to' blanks(2) num2str(xfiles)])
disp(blanks(30));
disp(['Minimum rms files = ' num2str(minrmsfiles)])
disp(['Minimum rms files = ' num2str(minrmsfiles)])
disp(['Average threshold = ' num2str(totalavgthresh)])
%%%%%%%%%%%%%%%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


else % when ncomp = 8
    
for totfiles = nfiles:-1:2;               %only goes down to the 2nd file  

    %get data
    
    alldata=[];
     
    
    for filenum = 1:totfiles;             
        load(B{filenum})
        
        alldata=[alldata 
                  data]; 
              
%         if totfiles==nfiles
%             dprimes=[dprimes dprime];
%         end
    end
    
    data= alldata;
    
prtbstandard=data(:,3:5);                   %column 3 through column 5 as perturbations of the standard
prtbsig=data(:,6:8);                        %all the rows for column 6 through column 8 pertsig
 
 
Int1= (prtbstandard - prtbsig);             %% *-1 prtb difference from pertsig to pertstd 
Int2= (Int1) * -1;

datainterval1 = [data(:,1:2) Int1];            %Creating matrix with column 1 to Column 2 and the prtb difference
datainterval2 = [data(:,1:2) Int2];             %values for when signal was in the first interval
                                                %and another datainterval2
                                                %matrix to account for when
                                                %signal is in 2nd interval

x=find(datainterval1(:,1)==1);               %check data in vector for all rows in Column 1-STIM, where the value ==1 (sig standard)
data1=datainterval1(x,:);                     %data1 contains when stim ==1, for all columns associated 
y=find(datainterval2(:,1)==2);               %all the rows in column 1 when value ==2
data2=datainterval2(y,:); 

                                             %when signal was in second interval


 
%deleting column 1 from data
data1(:,1)=[];                      %all rows for column one which was STIM deleted               
data2(:,1)=[];                      %all rows for column one from data2 deleted



                                         %R P1 P2 P3 (R=responses) 
                                     %R   1
                                     %P1     1
                                     %P2        1
                                     %P3          1
                                     
r1=corrcoef(data1) ;                 %get the correlated coefficients for vector data 1                               
w1=r1(1,2:4);                        %matrix row 1 from 2column to the 5column (instead of 4, leve rove) holds the corcoeff needed
maxw1=max(abs(w1));                  %highest abs value from the corrcoeff matrix
w1=w1/maxw1 ;                          %normalize over the maximum value
% w1= -1*w1

r2=corrcoef(data2);                 %correlation coefficient for set of data when stim was 2 
w2=r2(1,2:4);                       %weights are values found in row 1 from column 2-5 due to level rove weights
maxw2=max(abs(w2));                  %normalizing by the largest value weight
w2= w2/maxw2;                         
% w2= -1*w2 ;         %sign change not above (*-1)
% wgts=(w1+w2)/2;                     %take the average 

    

    ncomptone=3;                  %# of tone complexes or in the future use length(w1)
    allrms(nfiles+1-totfiles)=sqrt((w1-w2)*(w1-w2)'/ncomptone); %
    xnotation(nfiles+1-totfiles)=totfiles;
    

end %totfiles (jjj)
% xnotation=fliplr(xnotation);
subplot(2,1,2), plot(xnotation,allrms)
title('Blocks used in rms calculation');
xlabel('Each block number is subtracted from the very last block completed');
ylabel('rms');
pause




%$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
%recalculate weights for minimum rms
allrms=fliplr(allrms); %flip because this affects index location
[C,I]=min(allrms); % returns C as scalar value for rms and 'I' as the index for where it is located on vector
nfiles=I+1;   %find(index==allrms)            


%get data
alldata=[];

for filenum=1:nfiles;
    load(B{filenum})
    alldata=[alldata
        data];
end

data=alldata;

prtbstandard=data(:,3:5);                   %all the rows for column 3 through column 5 for pertstd
prtbsig=data(:,6:8);                        %all the rows for column 6 through column 8 pertsig
Int1= (prtbstandard - prtbsig);             %% Int 1 when signal is in interval 1,  difference from pertsig to pertstd 
Int2= (Int1)* -1;

datainterval1 = [data(:,1:2) Int1];            %creating matrix with all the rows for column 1 to Column 2 and 4
datainterval2 = [data(:,1:2) Int2];            %3 prtb difference values for when signal was in the first interval
                                                %and another datainterval2
                                                %%matrix to account for
                                                %%when signal is in 2nd interval
                                                

x=find(datainterval1(:,1)==1);               %check datainterval1 matrix for Column 1-STIM, where the value ==1 (sig standard)
data1=datainterval1(x,:);                     %data1 contains when stim ==1, for all columns associated 
y=find(datainterval2(:,1)==2);               %looking in matrix datainterval2 for column 1 when value ==2
data2=datainterval2(y,:); 


%deleting column 1 from data
data1(:,1)=[];                      %all rows for column one deleted               
data2(:,1)=[];                      %all rows for column one from data2 deleted



                                         %R P1 P2 P3 
                                     %R   1
                                     %P1     1
                                     %P2        1
                                     %P3          1
                                     
r1=corrcoef(data1);                  %get the correlated coefficients for vector data 1                               
w1=r1(1,2:4);                       %matrix row 1 from 2column to the 4column holds the corcoeff needed
maxw1=max(abs(w1));                  %highest abs value from the corrcoeff matrix
w1=w1/maxw1;                          %normalize over the maximum value
% w1=-1*w1 ;                           %accounting for the different intervals
    
r2=corrcoef(data2);                 %correlation coefficient for set of data when stim was 2 
w2=r2(1,2:4);                       %weights are values found in row 1 from column 2-4.
maxw2=max(abs(w2));                  %normalizing by the largest value weight
w2= w2/maxw2 ;                        
% w2= -1*w2   ;                        %sign change here for when not above

wgts=(w1+w2)/2;  
rms=sqrt((w1-w2)*(w1-w2)'/ncomptone);
nfiles;
minrmsfiles=nfiles;
startminrmsfiles= xfiles-(nfiles-1); %account for indexing shift
%PLOT WEIGHTS

figure 
axis([0,4,-1,1]);
hold on

plot(w1);
plot(w2,'r');
plot(wgts,'gp');
title('WEIGHTS');
legend('wgt1','wgt2','average')

pause
% hold off

clc;
currentdate=date;
rundate=datestr(currentdate,'mmmdd');
disp(blanks(30));
disp(['Date = ' rundate])
disp(blanks(30));
disp(['rms = ' num2str(rms)])
disp(blanks(30));
disp(['Total number of files = ' num2str(xfiles)])
disp(blanks(30));
disp(['Files opened starting from file: ' num2str(startminrmsfiles) blanks(2) 'to' blanks(2) num2str(xfiles)])
disp(blanks(30));
disp(['Minimum rms files = ' num2str(minrmsfiles)])
disp(['Minimum rms files = ' num2str(minrmsfiles)])
disp(['Average threshold = ' num2str(totalavgthresh)])

end; %if statement
end %rovignore
